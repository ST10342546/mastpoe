import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Picker } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

interface Book {
  title: string;
  author: string;
  genre: string;
  pages: number;
}

const genres = ['True Crime', 'Science Fiction', 'Horror', 'Romance', 'documentary'];

const Stack = createNativeStackNavigator();

const HomeScreen = ({ navigation }: any) => {
  const [books, setBooks] = useState<Book[]>([]);

  const lastBook = books[books.length - 1];
  const totalPages = books.reduce((acc, book) => acc + book.pages, 0);
  const averagePages = books.length > 0 ? totalPages / books.length : 0;

  return (
    <View style={styles.container}>
      {lastBook && (
        <>
          <Text>Last Book Read:</Text>
          <Text>Title: {lastBook.title}</Text>
          <Text>Author: {lastBook.author}</Text>
          <Text>Genre: {lastBook.genre}</Text>
          <Text>Pages: {lastBook.pages}</Text>
        </>
      )}
      <Text style={styles.total}>Total Pages Read: {totalPages}</Text>
      <Text style={styles.average}>Average Pages per Book: {averagePages.toFixed(2)}</Text>
      <Button title="Add New Book" onPress={() => navigation.navigate('AddBook', { setBooks })} />
      {/* <Button title="View History" onPress={() => navigation.navigate('History', { books })} />
      <Button title="View Genres" onPress={() => navigation.navigate('Genres', { books })} /> */}
    </View>
  );
};

const AddBookScreen = ({ route, navigation }: any) => {
  const { setBooks } = route.params;
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [genre, setGenre] = useState(genres[0]);
  const [pages, setPages] = useState('');

  const addBook = () => {
    const newBook = { title, author, genre, pages: parseInt(pages, 10) };
    setBooks((prevBooks: Book[]) => [...prevBooks, newBook]);
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <TextInput style={styles.input} placeholder="Title" value={title} onChangeText={setTitle} />
      <TextInput style={styles.input} placeholder="Author" value={author} onChangeText={setAuthor} />
      <Picker selectedValue={genre} onValueChange={(itemValue) => setGenre(itemValue)}>
        {genres.map((g) => (
          <Picker.Item key={g} label={g} value={g} />
        ))}
      </Picker>
      <TextInput style={styles.input} placeholder="Pages" keyboardType="numeric" value={pages} onChangeText={setPages} />
      <Button title="Add Book" onPress={addBook} />
    </View>
  );
};

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="AddBook" component={AddBookScreen} />
        {/* <Stack.Screen name="History" component={HistoryScreen} />
        <Stack.Screen name="Genres" component={GenreScreen} /> */}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#ffe4e1', // Light Pink
  },
  input: {
    width: '84%',
    borderWidth: 1,
    padding: 11,
    marginVertical: 12,
    backgroundColor: '#fff', // White
    borderRadius: 6,
  },
  total: {
    marginTop: 21,
    fontSize: 19,
    color: '#800080', // Purple
  },
  average: {
    marginTop: 12,
    fontSize: 19,
    color: '#800080', // Purple
  },
});

export default App;
//refrencing  
//W3Schools (n.d.). W3Schools Online Web Tutorials. [online] W3schools.com. Available at: https://www.w3schools.com/.
//Stack Overflow (2022). Stack Overflow - Where Developers Learn, Share, & Build Careers. [online] Stack Overflow. Available at: https://stackoverflow.com/.
// 
